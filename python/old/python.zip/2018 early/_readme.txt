

1) Inserir cabeçalho
Strategy;nPOIs;nUAV;SucessTax;V2V_range;ctRounds;dimX;simumationTimeMS;pathTime;TSP_threads;maxData;minData;globalAvgDelay;GSglobalAvgDelay;nMsgs;tourSize;throughput;TaxPerPathSize;mapName


2) tirar:
%
MiliSegs
_TSP_thread
map_
.txt


3) trocar , por .