# -*- coding: utf-8 -*-
"""
Created on Tue Aug 21 14:20:26 2018

@author: c061300
"""

DPI2SAVE=100

FILEIN="dadosDeEntrada.txt"
FILEPARSED="dadosDeEntrada_PARSED.txt"

#arquivos que pegasm todos os mapas e colocam em uma linha
FILEMEDIANS="out_by_stratUAVnPOIs_MEDIANAS.txt"
FILEAVGS="out_by_stratUAVnPOIs_AVGS.txt"
FILESTATS="out_by_stratUAVnPOIs_STATS.txt"

FILERAW="out_by_stratUAVnPOIs_RAW.txt"



FILEMAPMEDIANS="out_by_stratMAPnPOIs_MEDIANAS.txt"
FILEMAPAVGS="out_by_stratMAPnPOIs_AVGS.txt"
FILEMAPSTATS="out_by_stratMAPnPOIs_STATS.txt"






FILECHMEDIANS="out_by_stratnPOIs_MEDIANAS.txt"
FILECHAVGS="out_by_stratnPOIs_AVGS.txt"


DISTSIZES=0 # array for nPOIs/CHs numbers...

SINGLEUAVCOUNT=8 # ATTENTION ON RUNNERS!!! Check the inputfile from simulations (time vs REUSE flag for TSP and LKH)



